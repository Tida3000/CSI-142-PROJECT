public interface Reportable {
    void printReport();
    double getTotalRevenue();
}
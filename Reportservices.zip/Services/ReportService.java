import java.util.ArrayList;
import java.util.HashMap;
import sales.Sale;
import java.util.List;

public class ReportService implements Reportable {

    private List<Sale> salesHistory;

    public ReportService(List<Sale> salesHistory) {
        this.salesHistory = (salesHistory == null) ? new ArrayList<>() : salesHistory;
    }

    @Override
    public void printReport() {
        System.out.println("===== MARKET REPORT =====");
        System.out.println("Total Sales: " + salesHistory.size());
        System.out.println("Total Revenue: P" + getTotalRevenue());
        System.out.println("Most Popular Category: " + getMostPopularCategory());
    }

    @Override
    public double getTotalRevenue() {
        double total = 0;
        for (Sale sale : salesHistory) {
            String category = sale.getCategory();
            total += sale.getPrice();
        }
        return total;
    }

    private String getMostPopularCategory() {
        // simple logic
        // (you can improve with HashMap later)
        return "General"; 
    }
}